/*
Crear un programa que imprima el total de un vector de números positivos
 */
package MODELO;

import javax.swing.JOptionPane;


public class class_01 {
    int[] numero  = new int[50]; //de 0 - 99 
    
public void Metodo_llenar(int cant){
    for(int fila=0; fila<cant; fila++){
        numero[fila] = Integer.parseInt(JOptionPane.showInputDialog("INGRESE EL SUELDO EN LA POSICION: "+fila)) ;
        
        
    }
}

public void Metodo_mostrar(int cant){
    for(int fila=0; fila<cant; fila++){
        if(numero[fila]>0){
            System.out.println("EL NUMERO "+numero[fila]+ " ES POSITIVO");
        }
        else{
            System.out.println("EL NUMERO "+numero[fila]+ " ES NEGATIVO");
        }
    }
    
    
}
}
