//3. Diseñe un programa que lea un vector de 10 posiciones, luego determine si la quinta posición es
//positiva, si la primera posición es negativa y si la última posición es cero.
package MODELO;

import javax.swing.JOptionPane;

public class class_03 {
    float[] vectores=new float[100];
    public void Metodo_llenar_V(int cant)
    {
        for(int fila=0;fila<cant;fila++)
        {
           vectores[fila]=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el numero ya sea positivo o negativo"+ fila + ":"));
        }
    }
    
    public void Metodo_mostrar (int cant)
    {
        for(int fila=0; fila<cant;fila++)
        {
            System.out.println("El numero en la poscicion ["+fila+"] es :"+ vectores[fila]);
        }
    }
}