/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.util.Random;

/**
 *
 * @author Propietario
 */
public class class_13 {
    public int[] numeros;

    public class_13() {
        this.numeros = new int[10];
    }

    public void generarNumeros() {
        Random random = new Random();
        System.out.println("Números generados al azar y su clasificación:");
        for (int i = 0; i < 10; i++) {
            numeros[i] = random.nextInt(3000) + 1;
            System.out.print(numeros[i] + " es ");
            if (esMultiploDe(numeros[i], 2)) {
                System.out.print("múltiplo de 2");
                if (esMultiploDe(numeros[i], 3) || esMultiploDe(numeros[i], 5)) {
                    System.out.print(", ");
                }
            }
            if (esMultiploDe(numeros[i], 3)) {
                System.out.print("múltiplo de 3");
                if (esMultiploDe(numeros[i], 5)) {
                    System.out.print(", ");
                }
            }
            if (esMultiploDe(numeros[i], 5)) {
                System.out.print("múltiplo de 5");
            }
            System.out.println();
        }
    }

    private boolean esMultiploDe(int numero, int divisor) {
        return numero % divisor == 0;
    }
}
