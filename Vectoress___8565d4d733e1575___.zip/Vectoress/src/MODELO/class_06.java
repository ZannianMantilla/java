/*
 6. Crear un programa para llenar dos vectores de 10 elementos y almacenar la suma de estos en un
tercer vector. Luego imprima este último vector por pantalla.
 */
package MODELO;

import java.util.Arrays;
import javax.swing.JOptionPane;

public class class_06 {
    float[] vectores=new float[100];
    float[] vectores2=new float[100];
    float[] vectores3=new float[100];
    public float suma_vectores;
    public void Metodo_llenar_V(int cant)
    {
        for(int fila=0; fila<cant;fila++)
        {
            vectores[fila]=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el numero correspondiente a cada vector1")); 
            vectores2[fila]=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el numero correspondiente a cada vector2"));
        }
    }
    public void Metodo_suma(int cant)
    {
        for(int fila=0; fila<cant;fila++)
        {
            suma_vectores=vectores[fila]+vectores2[fila];
            vectores3[fila]=suma_vectores;
            System.out.print(vectores3[fila]);
            
    }
    }
}

