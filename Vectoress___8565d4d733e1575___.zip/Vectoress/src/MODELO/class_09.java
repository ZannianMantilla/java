/*
Se requiere obtener las notas de todos los estudiantes del curso de algoritmia. Para esto, diseñé un
programa que permita ingresarlas en un vector, determinar el promedio de las mismas y luego
imprimirlas. Imprima también el promedio total obtenido.

 */
package MODELO;

import javax.swing.JOptionPane;

public class class_09 {
    int[] notas  = new int[50]; //de 0 - 49
    public double suma_notas = 0, prom;
    
public void Metodo_llenar(int cant){
    for(int fila=0; fila<cant; fila++){
        notas[fila] = Integer.parseInt(JOptionPane.showInputDialog("INGRESE LA NOTA EN LA POSICION: "+fila)) ;
        suma_notas += notas[fila] ;
    }
    prom = suma_notas / cant;
}

public void Metodo_mostrar(int cant){
    for(int fila=0; fila<cant; fila++){
        System.out.println("NOTA["+fila+"]: "+notas[fila]);
    }
    System.out.println("EL PROMEDIO TOTAL DE LAS "+suma_notas+" ES "+ prom);
}
}
