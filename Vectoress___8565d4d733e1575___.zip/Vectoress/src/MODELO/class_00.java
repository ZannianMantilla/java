/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import javax.swing.JOptionPane;

/**
 *
 * @author Propietario
 */
public class class_00 {
    float[] sueldos  = new float[100]; //de 0 - 99 
    String[] empleado = new String[100];
    public float suma_sueldo=0, prom;
    
public void Metodo_llenar(int cant){
    for(int fila=0; fila<cant; fila++){
        empleado[fila] = JOptionPane.showInputDialog("DIGITE EL NOMBRE DEL EMPLEADO "+fila+":");
        sueldos[fila] = Float.parseFloat(JOptionPane.showInputDialog("INGRESE EL SUELDO EN LA POSICION: "+fila)) ;
        suma_sueldo += sueldos[fila];
    }
    prom = suma_sueldo/cant;
}
    
public void Metodo_mostar(int cant){
    for(int fila=0; fila<cant; fila++){
        System.out.println("NOMBRE EMPLEADO [" + fila + "]:" + empleado[fila] + " Se le asigna el sueldo de: "+sueldos[fila]);
        //System.out.println("NOMBRE EMPLEADO [" + fila + "]:"  + empleado[fila]+ " Se le asigna el sueldo de: "sueldos[fila]);
        System.out.println("VECTOR["+fila+"]: "+sueldos[fila]);
    }
    System.out.println("PROMEDIO DE PAGO DE SUELDOS S: "+prom+" CON TOTAL DE SUELDOS ES: "+suma_sueldo) ;
}
}
