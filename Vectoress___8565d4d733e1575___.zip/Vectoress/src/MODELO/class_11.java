/*
El instructor SENA, desea obtener las notas de todos los aprendices de ADSO CIMI. Para esto, diseñé
un programa que permita ingresarlas en un vector y que además muestre por pantalla cuál fue la
mayor nota, y el nombre y número del aprendiz (posición) que la obtuvo.
 */
package MODELO;

import javax.swing.JOptionPane;


public class class_11 {
    int[] notas  = new int[50]; //de 0 - 49
    public int acu=0;
    
public void Metodo_llenar(int cant){
    for(int fila=0; fila<cant; fila++){
        notas[fila] = Integer.parseInt(JOptionPane.showInputDialog("INGRESE LA NOTA EN LA POSICION: "+fila)) ;
        acu = notas[fila];
        
    }
}     

public void Metodo_mostrar(int cant){
    for(int fila=0; fila<cant; fila++){
        System.out.println("LAS NOTAS ["+fila+"]: "+notas[fila]);
        
    }
    System.out.println("Y EL NUMERO MAYOR ES: "+ Math.max(acu, acu) );
    //System.out.println("EL ACUMULADOR ES " +acu+ " Y EL NUMERO MAYOR ES: "+ Math.max(acu, acu) );
}
}