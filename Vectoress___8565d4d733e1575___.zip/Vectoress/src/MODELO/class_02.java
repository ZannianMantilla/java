
package Modelo;


import javax.swing.JOptionPane;


public class class_02 {
    public float acumulado=0, prom;
    float[] promedio=new float[100];
    
    public void metodo_llenar (int cant){
        for (int fila=0; fila<cant; fila++ ){
            promedio[fila] = Float.parseFloat(JOptionPane.showInputDialog("INGRESE los valores de ls vectores : "));
            acumulado+=promedio[fila];
        }
        prom=acumulado/cant;
        
    }
    public void Metodo_mostar(int cant){
        for(int fila=0;fila<cant;fila++)
        {
            System.out.println("valor ["+fila+"]--"+ promedio[fila]);
        }
        System.out.println("del acumulado de ["+acumulado+"]el pomedio seria de : "+prom);
    
    }
    
    
}
