/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import javax.swing.JOptionPane;

public class class_04 {
    float[] numero = new float[20];

    public void Metodo_llenar_V(int cant) {
        for (int fila = 0; fila < cant; fila++) {
            numero[fila] = Float.parseFloat(JOptionPane.showInputDialog("Ingrese su número en la posición " + fila + ":"));
        }
    }

    public void Metodo_mostrar_V(int cant) {
        int menoresQue1000 = 0;
        int mayoresQue1000 = 0;

        for (int fila = 0; fila < cant; fila++) {
            if (numero[fila] < 1000) {
                menoresQue1000++;
            } else {
                mayoresQue1000++;
            }
        }

        System.out.println("Cantidad de números menores que 1000: " + menoresQue1000);
        System.out.println("Cantidad de números mayores que 1000: " + mayoresQue1000);
    }
}
/*
public class vista {
    float[] sueldos=new float[100];
    string[] empleado=new string[100];
    public float suma_sueldo=0,prom;
    public void Metodo_llenar_V(int cant)
    {
       for(int fila=0;fila<cant;fila++){
           sueldos[fila]=Float.parseFloat(JOptionPane.showInputDialog("ingrese el sueldo en su pocision:"+fila));
           empleado[fila]=JOptionPane.showInputDialog("ingrese el nombre del empleado:"+fila);
       }
    }
    public void Metodo_mostrar_V(int cant)
    {
    for(int fila=0;fila<=cant;fila++)
    {
    {
        System.out.println("Nombre Empleado["+fila+"]: "+empleado+"));
    }
    }
}
}
*/
