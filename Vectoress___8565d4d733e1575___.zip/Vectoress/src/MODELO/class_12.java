/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Propietario
 */
public class class_12 {
    
    public boolean F;
    public void metodo_N (String[] vector){
        boolean a = false, e = false, i = false, o = false, u = false;
        for (int x = 0; x < 100; x++){
            if (vector[x] != null) {
                if (vector[x].equals("a")){
                    a = true;
                }
                if (vector[x].equals("e")){
                    e = true;
                }
                if (vector[x].equals("i")){
                    i = true;
                }
                if (vector[x].equals("o")){
                    o = true;
                }
                if (vector[x].equals("u")){
                    u = true;
                }
            }
        }
        if (a == true && e == true && i == true && o == true && u == true){
            F = true;    
        }
    }

     
}
