/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;
import java.util.Scanner;

public class class_08 {
    private int[] vector;

    public class_08() {
        this.vector = new int[20];
    }

    public void ingresarValores() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese 20 valores enteros:");
        for (int i = 0; i < 20; i++) {
            System.out.print("Ingrese el valor " + (i + 1) + ": ");
            while (!scanner.hasNextInt()) {
                System.out.println("Por favor, ingrese un valor entero válido.");
                System.out.print("Ingrese el valor " + (i + 1) + ": ");
                scanner.next();
            }
            vector[i] = scanner.nextInt();
        }
    }

    public int[] invertirVector() {
        int[] vectorInvertido = new int[20];
        for (int i = 0; i < 20; i++) {
            vectorInvertido[i] = vector[19 - i];
        }
        return vectorInvertido;
    }

    public double calcularPromedio() {
        int sum = 0;
        for (int num : vector) {
            sum += num;
        }
        return (double) sum / vector.length;
    }

    public void posicionesSobrePromedio(double promedio) {
        System.out.println("Posiciones con valores por encima del promedio:");
        for (int i = 0; i < vector.length; i++) {
            if (vector[i] > promedio) {
                System.out.println("Posición " + i + ": " + vector[i]);
            }
        }
    }
}