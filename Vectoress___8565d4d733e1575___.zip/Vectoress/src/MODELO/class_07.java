/*
Diseñe un programa que cree dos vectores de tipo numérico y genere un tercer vector que contenga
el resultado de la suma del contenido de ambos vectores.
 */
package MODELO;

import javax.swing.JOptionPane;

public class class_07 {
    int[] vector_1  = new int[50]; //de 0 - 49 
    int[] vector_2  = new int[50]; //de 0 - 49
    int[] vector_3  = new int[50]; //de 0 - 49 
    public float suma_vector=0;
    
public void Metodo_llenar(int cant){
    for(int fila=0; fila<cant; fila++){
        vector_1[fila] = Integer.parseInt(JOptionPane.showInputDialog("INGRESE UN ELEMENTO PARA EL PRIMER VECTOR: "+fila));
        vector_2[fila] = Integer.parseInt(JOptionPane.showInputDialog("INGRESE UN ELEMENTO PARA EL SEGUNDO VECTOR: "+fila));
        vector_3[fila] = vector_1[fila] + vector_2[fila];
        suma_vector = vector_3[fila];
    }
}

public void Metodo_mostrar(int cant){
    for(int fila=0; fila<cant; fila++){
        //System.out.println("VECTOR["+fila+"]: "+vector_3);
    }
    System.out.println("LA SUMA DE LOS 2 VECTORES ES: "+suma_vector) ;
}

}
