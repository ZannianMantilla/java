/*
La empresa Distribuidora Ventura desea saber cuánto va a pagar del Impuesto sobre la Renta al final
del año 2023. Para esto ha realizado una proyección de las ventas mensuales. Desarrolle un programa
que permita ingresar las 12 ventas del año 2023 y determinar el impuesto a pagar por la suma de
dinero acumulada, según las siguientes condiciones:
• Si el total está entre $120,000 y $150,000 paga un 25%.
• Si el total está entre $150,001 y $250,000 paga un 27%.
• Si el total es mayor de $250,000 paga un 29%.
Nota: Debes imprimir el total de ventas del año y el monto del impuesto sobre la renta a pagar.
 */
package MODELO;

import javax.swing.JOptionPane;


public class class_10 {
    int[] ventas  = new int[50]; //de 0 - 49
    public double acu, des;
public void Metodo_llenar(int cant){
    for(int fila=0; fila<cant; fila++){
        ventas[fila] = Integer.parseInt(JOptionPane.showInputDialog("INGRESE LA VENTA EN EL INDICE: "+fila)) ;
        acu += ventas[fila];
        
        if(acu>=120000 && acu<=150000){
            des = acu * 0.25;
            System.out.println("EL TOTAL DE VENTAS ES DE: "+acu+" SU IMPUESTO A PAGAR ES DE: "+des);
            
        }
        
        if(acu>=150001 && acu<=250000){
            des = acu * 0.27;
            System.out.println("EL TOTAL DE VENTAS ES DE: "+acu+" SU IMPUESTO A PAGAR ES DE: "+des);
        }
        
        if(acu>250000){
            des = acu * 0.29;
            System.out.println("EL TOTAL DE VENTAS ES DE: "+acu+" SU IMPUESTO A PAGAR ES DE: "+des);
        }
        
    }
}

public void Metodo_mostrar(int cant){
    for(int fila=0; fila<cant; fila++){
    }
    
}
}
