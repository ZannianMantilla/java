/*
 v14. Una empresa tiene dos turnos (mañana y tarde) en los que trabajan 8 empleados (4 por la mañana y
4 por la tarde). Codificar un programa que permita almacenar los sueldos de los empleados
agrupados por turno. Imprimir los gastos en sueldos de cada turno.

 */
package MODELO;

import javax.swing.JOptionPane;

public class class_14 {
    
    String[] empleado=new String[20];
    String[] empleado2=new String[20];
    int[] jornada=new int[4];
    
    public double sueldo1, sueldo2, acu_sueldo, acu_sueldo2;
    public void Metodo_llenar(int cant)
            
        {
            for (int fila=0; fila<cant;fila++){
            
                jornada[fila] = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su turno 1(Mañana) o 2(tarde)"));
                switch(jornada[fila]){
               
                    case 1:
                        empleado[fila] = JOptionPane.showInputDialog("DIGITE EL NOMBRE DEL EMPLEADO "+fila);
                    
                        sueldo1 = Double.parseDouble(JOptionPane.showInputDialog("INGRESE SU SUELDO: " + fila)) ;

                        acu_sueldo = sueldo1 + acu_sueldo;

                        System.out.println("NOMBRE EMPLEADO DE LA MAÑANA" + empleado[fila]+ " [ " + fila + " ] Se le asigna el sueldo de: "+acu_sueldo);
                        
                        break;
                        
                        
                    case 2:
                        empleado2[fila] = JOptionPane.showInputDialog("DIGITE EL NOMBRE DEL EMPLEADO "+fila);


                        sueldo2 = Double.parseDouble(JOptionPane.showInputDialog("INGRESE SU SUELDO: " + fila)) ;


                        acu_sueldo2 =  sueldo2 + acu_sueldo2;

                        System.out.println("NOMBRE EMPLEADO DE LA TARDE" + empleado2[fila]+ " [ " + fila + " ] Se le asigna el sueldo de: "+acu_sueldo2);
                        
                        break; 

                }
            }   
        }
}
                
    
        


