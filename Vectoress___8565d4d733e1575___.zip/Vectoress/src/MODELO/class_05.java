
package MODELO;

import javax.swing.JOptionPane;

public class class_05 {

    float[] numero = new float[20];

    public void Metodo_llenar_V(int cant) {
        for (int fila = 0; fila < cant; fila++) {
            numero[fila] = Float.parseFloat(JOptionPane.showInputDialog("Ingrese su número en la posición " + fila + ":"));
        }
        }
public void Metodo_mostrar_V(int cant) {
            int A[]={3, 9, 88, 7, 11, 76,29,31,20,77};
            for(int x=0; x<10;x++)
            if(A[x]% 2==0)
                    System.out.println("dato par en posicion:"+(x+1));
            else 
                    System.out.println("dato impar en posicion:"+(x+1));
        }
     
}





//package vista;
//
//import javax.swing.JOptionPane;
//
//public class NewClass {
//    float[] numero = new float[20];
//
//    public void Metodo_llenar_V(int cant) {
//        for (int fila = 0; fila < cant; fila++) {
//            numero[fila] = Float.parseFloat(JOptionPane.showInputDialog("Ingrese su número en la posición " + fila + ":"));
//        }
//    }
//
//    public void Metodo_mostrar_V(int cant) {
//        int menoresQue1000 = 0;
//        int mayoresQue1000 = 0;
//
//        for (int fila = 0; fila < cant; fila++) {
//            if (numero[fila] < 1000) {
//                menoresQue1000++;
//            } else {
//                mayoresQue1000++;
//            }
//        }
//
//        System.out.println("Cantidad de números menores que 1000: " + menoresQue1000);
//        System.out.println("Cantidad de números mayores que 1000: " + mayoresQue1000);
//    }
//}











//// Método para generar un vector de tamaño n con números aleatorios
//    public static int[] generarVector(int n) {
//        int[] vector = new int[n];
//        for (int i = 0; i < n; i++) {
//            vector[i] = (int) (Math.random() * 100); // Generar números aleatorios entre 0 y 99
//        }
//        return vector;
//    }
//
//    // Método para mostrar los elementos de un vector
//    public static void mostrarVector(int[] vector) {
//        System.out.print("Vector: ");
//        for (int num : vector) {
//            System.out.print(num + " ");
//        }
//        System.out.println();
//    }
//
//    // Método para contar la cantidad de números pares e impares en un vector
//    public static int[] contarParesImpares(int[] vector) {
//        int[] conteo = {0, 0}; // Índice 0 para pares, índice 1 para impares
//        for (int num : vector) {
//            if (num % 2 == 0) {
//                conteo[0]++; // Incrementar el contador de pares
//            } else {
//                conteo[1]++; // Incrementar el contador de impares
//            }
//        }
//        return conteo;
//    }
//}





/*
public class vista {
    float[] sueldos=new float[100];
    string[] empleado=new string[100];
    public float suma_sueldo=0,prom;
    public void Metodo_llenar_V(int cant)
    {
       for(int fila=0;fila<cant;fila++){
           sueldos[fila]=Float.parseFloat(JOptionPane.showInputDialog("ingrese el sueldo en su pocision:"+fila));
           empleado[fila]=JOptionPane.showInputDialog("ingrese el nombre del empleado:"+fila);
       }
    }
    public void Metodo_mostrar_V(int cant)
    {
    for(int fila=0;fila<=cant;fila++)
    {
    {
        System.out.println("Nombre Empleado["+fila+"]: "+empleado+"));
    }
    }
}
}
*/


/*
import javax.swing.JOptionPane;

public class Vista {
    float[] sueldos = new float[100];
    String[] empleado = new String[100];
    public float suma_sueldo = 0, prom;

    public void metodo_llenar_V(int cant) {
        for (int fila = 0; fila < cant; fila++) {
            sueldos[fila] = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el sueldo en su posición " + fila + ":"));
            empleado[fila] = JOptionPane.showInputDialog("Ingrese el nombre del empleado " + fila + ":");
        }
    }

    public void metodo_mostrar_V(int cant) {
        for (int fila = 0; fila < cant; fila++) {
            JOptionPane.showMessageDialog(null, "Nombre Empleado[" + fila + "]: " + empleado[fila]);
        }
    }
*/


/*
se divide entre 2 y su residuo es 0, quiere decir que es divisible entre 2 y además es par. En cambio, cuando un número entero se divide entre 2 y su residuo es 1, quiere decir que no es divisible entre 2 y además es impar.
*/