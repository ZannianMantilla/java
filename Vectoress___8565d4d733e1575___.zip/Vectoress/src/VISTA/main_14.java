/*
 14. Una empresa tiene dos turnos (mañana y tarde) en los que trabajan 8 empleados (4 por la mañana y
4 por la tarde). Codificar un programa que permita almacenar los sueldos de los empleados
agrupados por turno. Imprimir los gastos en sueldos de cada turno.

 */
package VISTA;

import MODELO.class_14;
import javax.swing.JOptionPane;

public class main_14 {

    public static void main(String[] args) {
        // TODO code application logic here
        class_14 empresa = new class_14();
        
        int n_cant = Integer.parseInt(JOptionPane.showInputDialog("ingrese el ciclo"));
        
        empresa.Metodo_llenar(n_cant);
        
        
    }
    
}
