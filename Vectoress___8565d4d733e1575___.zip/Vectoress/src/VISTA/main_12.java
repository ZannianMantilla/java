/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Vista;

import javax.swing.JOptionPane;
import Modelo.class_12;

/**
 *
 * @author Propietario
 */
public class main_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        class_12 class12 = new class_12();
        String[] vector = new String[100];
        String[] letras = new String[100];
        
        for (int i = 0; i < 100; i++){
            String num=JOptionPane.showInputDialog("INGRESE la letra: ");
            vector[i] = num;
            letras[i] = num;
            
            class12.metodo_N(vector);
                    
            if (class12.F == true){
                break;
            }
        }
        
        JOptionPane.showMessageDialog(null, letras);
       
        
    }
    
}
