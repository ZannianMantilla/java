/*
El instructor SENA, desea obtener las notas de todos los aprendices de ADSO CIMI. Para esto, diseñé
un programa que permita ingresarlas en un vector y que además muestre por pantalla cuál fue la
mayor nota, y el nombre y número del aprendiz (posición) que la obtuvo.
 */
package VISTA;

import MODELO.class_11;
import javax.swing.JOptionPane;


public class main_11 {

    
    public static void main(String[] args) {
        // TODO code application logic here
        class_11 adso = new class_11();
        int n_cant = Integer.parseInt(JOptionPane.showInputDialog("INGRESE CANTIDAD DE ELEMENTOS DEL VECTOR: "));
        
        adso.Metodo_llenar(n_cant);
        adso.Metodo_mostrar(n_cant);
    }
    
}
