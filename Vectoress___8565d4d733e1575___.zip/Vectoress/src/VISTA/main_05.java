/*
 Crea un programa para ingresar valores enteros en un vector de 20 elementos. Luego genere un
nuevo vector con los elementos al revés del primero y determine e imprima el promedio de los
valores y cuáles posiciones contienen valores por encima del promedio
 */
package VISTA;

import MODELO.class_05;


public class main_05 {
    public static void main(String[] args) {
        class_05 obj = new class_05(); 
        obj.Metodo_llenar_V(20);
        obj.Metodo_mostrar_V(20);
    }
}
