/*
6. Crear un programa para llenar dos vectores de 10 elementos y almacenar la suma de estos en un
tercer vector. Luego imprima este último vector por pantalla.
*/
package VISTA;

import MODELO.class_06;
import javax.swing.JOptionPane;

public class main_06 {

    public static void main(String[] args) {
        // TODO code application logic here
        class_06 suma=new class_06();
        float[] vect=new float[100];
        int n_cant= Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de elementos del vector "));
        suma.Metodo_llenar_V(n_cant);
        suma.Metodo_suma(n_cant);
 
    }
    
}
