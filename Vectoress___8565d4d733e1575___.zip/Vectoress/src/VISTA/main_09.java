/*
Se requiere obtener las notas de todos los estudiantes del curso de algoritmia. Para esto, diseñé un
programa que permita ingresarlas en un vector, determinar el promedio de las mismas y luego
imprimirlas. Imprima también el promedio total obtenido.

 */
package VISTA;

import MODELO.class_09;
import javax.swing.JOptionPane;

public class main_09 {

    
    public static void main(String[] args) {
        // TODO code application logic here
        class_09 promedio = new class_09();
        int n_cant = Integer.parseInt(JOptionPane.showInputDialog("INGRESE CANTIDAD DE ELEMENTOS DEL VECTOR: "));
        promedio.Metodo_llenar(n_cant);
        promedio.Metodo_mostrar(n_cant);
    }
    
}
