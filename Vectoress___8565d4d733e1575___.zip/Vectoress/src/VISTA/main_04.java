/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package modelo;

import vista.class_04;

/*
 
 Programa que calcule la cantidad de números menores que 1000 y mayores que 1000 en un vector
de 20 posiciones.
 */
public class main_04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        class_04 obj = new class_04();
        obj.Metodo_llenar_V(20);
        obj.Metodo_mostrar_V(20);
    }
}
/*
public class modelo {

    
      @param args the command line arguments
    
    public static void main(String[] args) {
       vista vector=new vista();
        float[] sueldos=new float[100];
        int n_cant=Integer.parseInt(JOptionPane.showInputDialog("ingrese la cantidad del vector"));
        vector.Metodo_llenar_V(n_cant);
        vector.Metodo_mostrar_V(n_cant);
    }
    
}

*/