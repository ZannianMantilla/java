/*
La empresa Distribuidora Ventura desea saber cuánto va a pagar del Impuesto sobre la Renta al final
del año 2023. Para esto ha realizado una proyección de las ventas mensuales. Desarrolle un programa
que permita ingresar las 12 ventas del año 2023 y determinar el impuesto a pagar por la suma de
dinero acumulada, según las siguientes condiciones:
• Si el total está entre $120,000 y $150,000 paga un 25%.
• Si el total está entre $150,001 y $250,000 paga un 27%.
• Si el total es mayor de $250,000 paga un 29%.
Nota: Debes imprimir el total de ventas del año y el monto del impuesto sobre la renta a pagar.
 */
package VISTA;
import MODELO.class_10;
import javax.swing.JOptionPane;

/**
 *
 * @author Propietario
 */
public class main_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        class_10 impuesto = new class_10();
        int n_cant = Integer.parseInt(JOptionPane.showInputDialog("INGRESE CANTIDAD DE ELEMENTOS DEL VECTOR: "));
        impuesto.Metodo_llenar(n_cant);
        
    }
}
