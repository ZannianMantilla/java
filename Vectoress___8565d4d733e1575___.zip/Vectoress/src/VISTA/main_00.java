/*
CREAR UN VECTOR DE N NUMEROS Y RECORRERLO 
 */
package VISTA;

import MODELO.class_00;
import javax.swing.JOptionPane;

public class main_00 {

    public static void main(String[] args) {
        // TODO code application logic here
        class_00 vector = new class_00();
        
        
        //DEFINIR EL VECTOR
        //float[] sueldos  = new float[100]; //de 0 - 99 
        int n_cant = Integer.parseInt(JOptionPane.showInputDialog("INGRESE CANTIDAD DE ELEMENTOS DEL VECTOR: "));
        vector.Metodo_llenar(n_cant);
        vector.Metodo_mostar(n_cant);
    }
    
}
