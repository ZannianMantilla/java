/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package VISTA;

import MODELO.class_08;

/**
 *
 * @author Propietario
 */
public class main_08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        class_08 vectorOp = new class_08();
        vectorOp.ingresarValores();
        int[] vectorInvertido = vectorOp.invertirVector();
        double promedio = vectorOp.calcularPromedio();
        vectorOp.posicionesSobrePromedio(promedio);
    }
}