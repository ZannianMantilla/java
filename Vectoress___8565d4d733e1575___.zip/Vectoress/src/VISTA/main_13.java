/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package VISTA;

import MODELO.class_13;

/**
 Generar diez números al azar (usar la función random entre [1 a 3000] y mostrarlos en pantalla junto
al texto) es múltiplo de 2,3 o 5. Según corresponda.
 */
public class main_13 {

    /**
     * @param args the command line arguments
     */
       public static void main(String[] args) {
        class_13 numerosAleatorios = new class_13();
        numerosAleatorios.generarNumeros();
    }
}
