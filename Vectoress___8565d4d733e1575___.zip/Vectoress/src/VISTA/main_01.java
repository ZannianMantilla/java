/*
Crear un programa que imprima el total de un vector de números positivos
 */
package VISTA;

import MODELO.class_01;
import javax.swing.JOptionPane;

/**

 * @author Propietario
 */
public class main_01 {


    public static void main(String[] args) {
        // TODO code application logic here
        class_01 positivo = new class_01();
        
        int n_cant = Integer.parseInt(JOptionPane.showInputDialog("INGRESE CANTIDAD DE ELEMENTOS DEL VECTOR: "));
        positivo.Metodo_llenar(n_cant);
        positivo.Metodo_mostrar(n_cant);
        
    }
    
}
