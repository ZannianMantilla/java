/*
Diseñe un programa que cree dos vectores de tipo numérico y genere un tercer vector que contenga
el resultado de la suma del contenido de ambos vectores.
 */
package VISTA;

import MODELO.class_07;
import javax.swing.JOptionPane;


public class main_07 {

    public static void main(String[] args) {
        // TODO code application logic here
        class_07 suma = new class_07();
        
        int[] numero  = new int[50]; //de 0 - 99 
        
        int n_cant = Integer.parseInt(JOptionPane.showInputDialog("INGRESE CANTIDAD DE ELEMENTOS DEL VECTOR: "));
        suma.Metodo_llenar(n_cant);
        suma.Metodo_mostrar(n_cant);
    }
    
}
