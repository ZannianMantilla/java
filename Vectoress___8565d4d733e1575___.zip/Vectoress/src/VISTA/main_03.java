//3. Diseñe un programa que lea un vector de 10 posiciones, luego determine si la quinta posición es
//positiva, si la primera posición es negativa y si la última posición es cero.
package VISTA;

import MODELO.class_03;
import javax.swing.JOptionPane;

public class main_03 {

    public static void main(String[] args) {
        // TODO code application logic here
        class_03 vect=new class_03();
       float[] vectores=new float[100];
       int n_cant = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de elementos del vector"));
       vect.Metodo_llenar_V(n_cant);
       vect.Metodo_mostrar(n_cant);
    }
    
}